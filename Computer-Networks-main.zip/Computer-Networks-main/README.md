# Computer-Networks
Various real life problem statements are provided. We need to solve those problems using networking logic in C language. Figuring out the problem through using the logics of Computer Networks
