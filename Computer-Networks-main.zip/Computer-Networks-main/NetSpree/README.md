#NIT WARANGAL FEST
4 processes exist named Rececption process , Technical Process , Cultural process , score board 

#problem statement 
R , T, , C exist on same system. Score board and all different participant process are in diff system 
A partiocipant either request for T or C at different sfds . R accepts and pass it to the chosen process. R also sends its info to SC process which displays it.
T process gandkes each Pi process with seperte threads. T conducts an event like : 
i. asks to choose between 0 to 50 .
ii. t it selfs generate a random number n . 
iii. recives number from each pi 
iv announces the winner or looser among all the process P by comparing number of both processes and the T. 
v. sends result to SC

Similar for C process , instead of using numbber between 0 to 50 use chars between A-Z 
